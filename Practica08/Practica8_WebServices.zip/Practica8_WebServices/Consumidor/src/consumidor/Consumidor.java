
package consumidor;


public class Consumidor {

  
    public static void main(String[] args) 
    {
        /*
        String tarjeta = "1670 9087 5430 8952";
        float total = 9999;
        String nombre = "Juanito Perengano";
        int CVV = 444;
        boolean pago = pagar(tarjeta,total,nombre,CVV);
        
        if(pago == true)
        System.out.println("El pago fue exitoso");
        else
        System.out.println("El pago fue declinado");
        */
        
        int ID = 10;
        int numero_de_productos = 2;
        int pedidos_totales = 6;
        boolean compra = comprar(ID,numero_de_productos,pedidos_totales);
        
        if(compra == true)
        System.out.println("Su compra fue realizada con éxito");
        else
        System.out.println("La compra no se pudo realizar");
       
    }

    private static boolean comprar(int idProducto, int numeroProductos, int totalPedidos) 
    {
        consumidor.Servidor service = new consumidor.Servidor();
        consumidor.ServidorWS port = service.getServidorWSPort();
        return port.comprar(idProducto, numeroProductos, totalPedidos);
    }

    private static boolean pagar(java.lang.String numeroTarjeta, float monto, java.lang.String nombre, int codigoCVV) 
    {
        consumidor.Servidor service = new consumidor.Servidor();
        consumidor.ServidorWS port = service.getServidorWSPort();
        return port.pagar(numeroTarjeta, monto, nombre, codigoCVV);
    }
    
}
