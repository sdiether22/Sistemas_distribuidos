package org.me.ServidorWS;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

@WebService(serviceName = "Servidor")
@Stateless()
public class ServidorWS 
{
    public String tarjeta1 = "1670 9087 5430 8952";
    public String nombre1 = "Juanito Perengano";
    public int CVV1 = 444;
    
    public int producto1 = 1;
    public int stock = 10;

    @WebMethod(operationName = "comprar")
    @RequestWrapper(className = "org.comprar")
    @ResponseWrapper(className = "org.comprarResponse")
    public boolean pagar(@WebParam(name = "id_producto") int id_producto, @WebParam(name = "numero_productos") int numero_productos, @WebParam(name = "total_pedidos") int total_pedidos) 
    {  
        if(id_producto == producto1)
        {
            if(stock >= numero_productos*total_pedidos)
            {
              return true;
            }
            else
            {
              return false;
            }
        }
        else
        {
            return false;
        }
    }
    
    
    
     @WebMethod(operationName = "pagar")
    public boolean pagar(@WebParam(name = "numero_tarjeta") String numero_tarjeta, @WebParam(name = "monto") float monto ,@WebParam(name = "nombre") String nombre, @WebParam(name = "codigo_CVV") int codigo_CVV) 
    {
        float saldo = 10000;
        if(numero_tarjeta.equals(tarjeta1) && codigo_CVV == CVV1 && nombre.equals(nombre1))
        {
                    if(saldo>=monto)
                    {
                        /* saldo = saldo - monto; */
        		return true;
                    }
                    else
                    {
        		return false;
                    }      	
        }
        else
        {
            return false;
        }
     
    }
    
}
